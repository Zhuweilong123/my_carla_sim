# Algorithm utilities
